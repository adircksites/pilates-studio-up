const booking = document.querySelector('#booking-form');
const link = document.querySelector('#wa-booking');
function updateBookingLink() {
  const data = new FormData(booking);
  const name = String(data.get('nome')).trim();
  const preference = [data.get('dia'), data.get('periodo')].filter(Boolean).join(', ');
  const message = ['Olá!', name && 'Meu nome é ' + name + '.', 'Gostaria de consultar os horários para uma aula de Pilates.', preference && 'Preferência: ' + preference + '.'].filter(Boolean).join(' ');
  link.href = 'https://wa.me/5521997723626?text=' + encodeURIComponent(message);
}
booking.addEventListener('input', updateBookingLink);
booking.addEventListener('submit', (event) => { event.preventDefault(); updateBookingLink(); link.click(); });
link.addEventListener('click', updateBookingLink);
const dialog = document.querySelector('#photo-dialog');
const fullImage = dialog.querySelector('img');
document.querySelectorAll('[data-photo]').forEach((button) => {
  button.addEventListener('click', () => {
    fullImage.src = button.dataset.photo;
    fullImage.alt = button.querySelector('img').alt;
    dialog.showModal();
  });
});
dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
